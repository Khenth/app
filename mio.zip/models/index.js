

const Categorie = require('./categories');
const Role = require('./role');
const Server = require('./server');
const User = require('./user');
const Product = require('./product');

module.exports={
    Categorie,
    Role,
    Server,
    User,
    Product,
}